# main.py — Telegram-бот магазина

import asyncio
import logging
import os
import sys

from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message

# Проверка наличия модуля ssl
try:
    import ssl
except ModuleNotFoundError:
    print("Ошибка: модуль ssl не найден. Убедитесь, что ваша система поддерживает SSL.")
    sys.exit(1)

# Получение токена из переменной среды или указание вручную
BOT_TOKEN = os.getenv("BOT_TOKEN") or "ВСТАВЬ_СЮДА_СВОЙ_ТОКЕН"

if BOT_TOKEN == "ВСТАВЬ_СЮДА_СВОЙ_ТОКЕН":
    print("Ошибка: Вы не указали токен бота. Установите его в переменную окружения BOT_TOKEN или вставьте прямо в код.")
    sys.exit(1)

# Настройка логирования
logging.basicConfig(level=logging.INFO)

# Создание экземпляров бота и диспетчера
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher(storage=MemoryStorage())

# Обработка команды /start
@dp.message(commands=["start"])
async def start_command(message: Message):
    await message.answer("Привет! Я твой магазин-бот. Выбери товар и оплати 💳")

# Обработка всех остальных сообщений
@dp.message()
async def handle_message(message: Message):
    await message.answer("Напиши /start, чтобы начать пользоваться ботом")

# Главная функция запуска бота
async def main():
    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
